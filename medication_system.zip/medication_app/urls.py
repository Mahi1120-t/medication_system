# medication_app/urls.py
from django.urls import path
from . import views

app_name = 'medication_app'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('medications/', views.medication_list, name='medication_list'), 
    path('medications/add/', views.add_medication, name='add_medication'),
    path('interactions/', views.check_interactions, name='check_interactions'),
    path('disposal/', views.disposal_guidelines, name='disposal_guidelines'),
    path('users/', views.user_management, name='user_management'),
    path('ocr-scan/', views.ocr_scan, name='ocr_scan'),
    path('medications/<int:pk>/edit/', views.edit_medication, name='edit_medication'),
    path('medications/<int:pk>/delete/', views.delete_medication, name='delete_medication'),
    path('medications/lookup/', views.medication_lookup, name='medication_lookup'),
]