# medication_app/models.py
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
from datetime import date

class Medication(models.Model):
    name = models.CharField(max_length=200)
    dosage = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    expiry_date = models.DateField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    barcode = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def is_expired(self):
        return self.expiry_date < date.today()
    
    def expires_soon(self):
        days_until_expiry = (self.expiry_date - date.today()).days
        return 0 <= days_until_expiry <= 30
    
    def __str__(self):
        return f"{self.name} ({self.dosage})"
    
    class Meta:
        ordering = ['expiry_date']

class DrugInteraction(models.Model):
    medication1 = models.ForeignKey(Medication, on_delete=models.CASCADE, related_name='interactions_as_first')
    medication2 = models.ForeignKey(Medication, on_delete=models.CASCADE, related_name='interactions_as_second')
    severity = models.CharField(max_length=50)
    description = models.TextField()
    
    def __str__(self):
        return f"{self.medication1.name} + {self.medication2.name} - {self.severity}"