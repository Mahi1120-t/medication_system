# medication_app/admin.py
from django.contrib import admin
from .models import Medication, DrugInteraction

@admin.register(Medication)
class MedicationAdmin(admin.ModelAdmin):
    list_display = ('name', 'dosage', 'quantity', 'expiry_date', 'user', 'is_expired')
    list_filter = ('expiry_date', 'user')
    search_fields = ('name',)

@admin.register(DrugInteraction)
class DrugInteractionAdmin(admin.ModelAdmin):
    list_display = ('medication1', 'medication2', 'severity')
    search_fields = ('medication1', 'medication2')