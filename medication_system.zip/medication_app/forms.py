# medication_app/forms.py
from django import forms
from .models import Medication

class MedicationForm(forms.ModelForm):
    class Meta:
        model = Medication
        fields = ['name', 'dosage', 'quantity', 'expiry_date', 'barcode']
        widgets = {
            'expiry_date': forms.DateInput(attrs={'type': 'date'}),
        }