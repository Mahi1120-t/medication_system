# medication_app/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import timedelta
from .models import Medication
from .forms import MedicationForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
import pytesseract
from PIL import Image
from django.shortcuts import redirect

def root_redirect(request):
    return redirect('medication_app:dashboard')

def is_admin(user):
    return user.is_superuser

@login_required
@user_passes_test(is_admin)
def user_management(request):
    all_users = User.objects.all()  
    return render(request, 'medication_app/user_management.html', {'users': all_users})

@login_required
def ocr_scan(request):
    if request.method == 'POST' and request.FILES.get('image'):
        try:
            # Save uploaded image
            image_file = request.FILES['image']
            fs = FileSystemStorage()
            filename = fs.save(image_file.name, image_file)
            
            # Process with OCR
            image_path = fs.path(filename)
            text = pytesseract.image_to_string(Image.open(image_path))
            
            # Clean up
            fs.delete(filename)
            
            return JsonResponse({'success': True, 'text': text})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'No image provided'})
@login_required
def dashboard(request):
    medications = Medication.objects.filter(user=request.user)
    expiring_meds = medications.filter(
        expiry_date__lte=timezone.now().date() + timedelta(days=30)
    )
    expired_meds = medications.filter(expiry_date__lt=timezone.now().date())
    
    context = {
        'medications': medications,
        'expiring_meds': expiring_meds,
        'expired_meds': expired_meds,
        'total_meds': medications.count(),
    }
    return render(request, 'medication_app/dashboard.html', context)

@login_required
def medication_list(request):
    medications = Medication.objects.all().order_by('name')
    return render(request, 'medication_app/medication_list.html', {'medications': medications})

@login_required
def add_medication(request):
    if request.method == 'POST':
        form = MedicationForm(request.POST)
        if form.is_valid():
            medication = form.save(commit=False)
            medication.user = request.user
            medication.save()
            return redirect('medication_app:medication_list')  # Use namespace
@login_required
def edit_medication(request, pk):
    medication = get_object_or_404(Medication, pk=pk, user=request.user)
    if request.method == 'POST':
        form = MedicationForm(request.POST, instance=medication)
        if form.is_valid():
            form.save()
            return redirect('medication_app:medication_list')
    else:
        form = MedicationForm(instance=medication)
    return render(request, 'medication_app/medication_form.html', {'form': form})

@login_required
def delete_medication(request, pk):
    medication = get_object_or_404(Medication, pk=pk, user=request.user)
    if request.method == 'POST':
        medication.delete()
        return redirect('medication_app:medication_list')
    return render(request, 'medication_app/medication_confirm_delete.html', {'medication': medication})
@login_required
def check_interactions(request):
    medications = Medication.objects.filter(user=request.user)
    interactions = []
    
    if request.method == 'POST':
        selected_meds = request.POST.getlist('medications')
        interactions = check_drug_interactions(selected_meds)
    
    return render(request, 'medication_app/interaction_checker.html', {
        'medications': medications,
        'interactions': interactions
    })


@login_required
def disposal_guidelines(request):
    guidelines = [
        {
            'title': 'Medication Take-Back Programs',
            'description': 'The best way to dispose of most types of unused or expired medicines is to drop them off at a drug take-back location.',
            'icon': 'fas fa-truck-arrow-right'
        },
        {
            'title': 'Flushing Medications',
            'description': 'Some medicines may be especially harmful and, in some cases, fatal to anyone who uses them if not disposed of properly.',
            'icon': 'fas fa-faucet'
        },
        {
            'title': 'Household Trash',
            'description': 'If no take-back programs are available, most medicines can be thrown in your household trash.',
            'icon': 'fas fa-trash'
        },
        {
            'title': 'Don\'t Crush Tablets',
            'description': 'Avoid crushing tablets or capsules when disposing them.',
            'icon': 'fas fa-tablets'
        }
    ]
    
    return render(request, 'medication_app/disposal_guidelines.html', {'guidelines': guidelines})

@login_required
def medication_lookup(request):
    barcode = request.GET.get('barcode', '')
    
    # Simple mock database - replace with real data
    mock_database = {
        '123456789012': {'name': 'Amoxicillin', 'dosage': '500mg', 'type': 'Capsule'},
        '987654321098': {'name': 'Lisinopril', 'dosage': '10mg', 'type': 'Tablet'},
        '456789123456': {'name': 'Metformin', 'dosage': '850mg', 'type': 'Tablet'},
    }
    
    if barcode in mock_database:
        return JsonResponse({'success': True, 'medication': mock_database[barcode]})
    else:
        return JsonResponse({'success': False, 'error': 'Medication not found'})
